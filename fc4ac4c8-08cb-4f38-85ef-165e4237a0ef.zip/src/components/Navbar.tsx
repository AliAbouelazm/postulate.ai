import React from 'react';
import { motion } from 'framer-motion';
export function Navbar() {
  return <motion.nav initial={{
    y: -100,
    opacity: 0
  }} animate={{
    y: 0,
    opacity: 1
  }} transition={{
    duration: 0.6,
    ease: 'easeOut'
  }} className="fixed top-0 left-0 right-0 z-50 px-6 py-5 backdrop-blur-2xl bg-black/50 border-b border-white/10">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <motion.div whileHover={{
        scale: 1.02
      }} className="flex items-center gap-2">
          <span className="text-xl font-bold text-gradient-animated tracking-tight">
            postulate.ai
          </span>
        </motion.div>

        <div className="hidden md:flex items-center gap-10">
          <motion.a href="#about" whileHover={{
          y: -2
        }} className="text-gray-400 hover:text-white transition-colors duration-300 font-normal text-sm">
            About
          </motion.a>
          <motion.a href="#how-it-works" whileHover={{
          y: -2
        }} className="text-gray-400 hover:text-white transition-colors duration-300 font-normal text-sm">
            How it Works
          </motion.a>
          <motion.a href="#login" whileHover={{
          scale: 1.02,
          boxShadow: '0 0 20px rgba(139, 92, 246, 0.3)'
        }} whileTap={{
          scale: 0.98
        }} className="px-6 py-2.5 rounded-lg bg-gradient-to-r from-blue-500 via-violet-500 to-pink-500 text-white font-semibold text-sm transition-all duration-300">
            Login
          </motion.a>
        </div>
      </div>
    </motion.nav>;
}