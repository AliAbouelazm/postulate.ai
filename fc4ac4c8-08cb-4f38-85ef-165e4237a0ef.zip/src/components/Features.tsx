import React from 'react';
import { motion } from 'framer-motion';
import { LightbulbIcon, BuildingIcon, ShieldCheckIcon, ArrowRight } from 'lucide-react';
const features = [{
  icon: LightbulbIcon,
  title: 'Submit Ideas',
  description: 'Share your innovative concepts with leading companies. Our AI ensures your ideas reach the right decision-makers.',
  gradient: 'from-blue-500 to-cyan-500',
  glowColor: 'rgba(59, 130, 246, 0.2)'
}, {
  icon: BuildingIcon,
  title: 'Company Reviews',
  description: 'Companies review submissions through our intelligent platform, discovering breakthrough innovations from talented creators.',
  gradient: 'from-violet-500 to-purple-500',
  glowColor: 'rgba(139, 92, 246, 0.2)'
}, {
  icon: ShieldCheckIcon,
  title: 'Secure NDA Workflow',
  description: 'Every submission is protected by our automated NDA system. Your intellectual property stays safe throughout the process.',
  gradient: 'from-pink-500 to-rose-500',
  glowColor: 'rgba(236, 72, 153, 0.2)'
}];
export function Features() {
  return <div className="py-40 px-6 relative">
      {/* Background accent */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div animate={{
        scale: [1, 1.2, 1],
        opacity: [0.08, 0.15, 0.08]
      }} transition={{
        duration: 12,
        repeat: Infinity,
        ease: 'easeInOut'
      }} className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-violet-500/15 rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div initial={{
        opacity: 0,
        y: 30
      }} whileInView={{
        opacity: 1,
        y: 0
      }} viewport={{
        once: true
      }} transition={{
        duration: 0.8
      }} className="text-center mb-32">
          <motion.h2 className="text-5xl md:text-6xl font-bold mb-8 tracking-tight" animate={{
          backgroundPosition: ['0% 50%', '100% 50%', '0% 50%']
        }} transition={{
          duration: 6,
          repeat: Infinity,
          ease: 'linear'
        }} style={{
          backgroundSize: '200% 100%'
        }}>
            How it{' '}
            <span className="bg-gradient-to-r from-blue-300 via-violet-300 to-pink-300 bg-clip-text text-transparent">
              works
            </span>
          </motion.h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto font-normal">
            A seamless platform connecting innovation with opportunity
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-12">
          {features.map((feature, index) => <motion.div key={feature.title} initial={{
          opacity: 0,
          y: 50
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} transition={{
          duration: 0.6,
          delay: index * 0.15
        }} className="group relative">
              {/* Subtle glow */}
              <motion.div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" style={{
            background: `linear-gradient(135deg, ${feature.glowColor}, transparent)`,
            filter: 'blur(30px)'
          }} />

              <motion.div whileHover={{
            y: -8
          }} transition={{
            duration: 0.3
          }} className="relative h-full p-12 rounded-2xl bg-gradient-to-b from-white/5 to-white/0 border border-white/10 backdrop-blur-xl hover:border-white/20 transition-all duration-300 overflow-hidden">
                {/* Subtle gradient overlay */}
                <motion.div className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-5 transition-opacity duration-500`} />

                <div className="relative">
                  {/* Icon */}
                  <motion.div whileHover={{
                rotate: 5,
                scale: 1.05
              }} transition={{
                duration: 0.4
              }} className={`inline-flex p-4 rounded-xl bg-gradient-to-br ${feature.gradient} mb-10`} style={{
                boxShadow: `0 8px 30px ${feature.glowColor}`
              }}>
                    <feature.icon className="w-8 h-8 text-white" />
                  </motion.div>

                  <h3 className="text-2xl font-bold mb-6 text-white tracking-tight">
                    {feature.title}
                  </h3>

                  <p className="text-gray-400 leading-relaxed text-base mb-8 font-normal">
                    {feature.description}
                  </p>

                  {/* Arrow indicator */}
                  <motion.div className="flex items-center gap-2 text-gray-500 group-hover:text-gray-300 transition-colors duration-300" whileHover={{
                x: 4
              }}>
                    <span className="text-sm font-medium">Learn more</span>
                    <ArrowRight className="w-4 h-4" />
                  </motion.div>

                  {/* Decorative line */}
                  <motion.div className={`mt-10 h-px rounded-full bg-gradient-to-r ${feature.gradient}`} initial={{
                width: '30%'
              }} whileInView={{
                width: '100%'
              }} viewport={{
                once: true
              }} transition={{
                duration: 1,
                delay: index * 0.2 + 0.5
              }} />
                </div>
              </motion.div>
            </motion.div>)}
        </div>

        {/* Bottom CTA */}
        <motion.div initial={{
        opacity: 0,
        y: 30
      }} whileInView={{
        opacity: 1,
        y: 0
      }} viewport={{
        once: true
      }} transition={{
        duration: 0.8
      }} className="mt-40 text-center">
          <motion.div whileHover={{
          scale: 1.01
        }} className="relative inline-block p-16 rounded-2xl bg-gradient-to-r from-blue-500/5 via-violet-500/5 to-pink-500/5 border border-white/10 backdrop-blur-xl overflow-hidden">
            {/* Subtle animated background */}
            <motion.div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 via-violet-500/10 to-pink-500/10" animate={{
            backgroundPosition: ['0% 50%', '100% 50%', '0% 50%']
          }} transition={{
            duration: 8,
            repeat: Infinity,
            ease: 'linear'
          }} style={{
            backgroundSize: '200% 100%'
          }} />

            <div className="relative z-10">
              <h3 className="text-4xl font-bold mb-6 tracking-tight">
                Ready to get started?
              </h3>
              <p className="text-gray-400 mb-10 max-w-xl mx-auto text-base font-normal">
                Join thousands of innovators and companies already using
                postulate.ai
              </p>
              <motion.button whileHover={{
              scale: 1.02,
              boxShadow: '0 0 30px rgba(139, 92, 246, 0.4)'
            }} whileTap={{
              scale: 0.98
            }} className="px-10 py-5 rounded-lg bg-gradient-to-r from-blue-500 via-violet-500 to-pink-500 text-white font-semibold text-base inline-flex items-center gap-3">
                Get Early Access
                <motion.div animate={{
                x: [0, 4, 0]
              }} transition={{
                duration: 2,
                repeat: Infinity
              }}>
                  <ArrowRight className="w-4 h-4" />
                </motion.div>
              </motion.button>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </div>;
}