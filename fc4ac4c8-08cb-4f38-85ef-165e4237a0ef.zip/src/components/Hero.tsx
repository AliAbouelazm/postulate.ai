import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
export function Hero() {
  // Generate floating particles
  const particles = Array.from({
    length: 15
  }, (_, i) => ({
    id: i,
    delay: i * 0.4,
    duration: 5 + Math.random() * 2,
    x: Math.random() * 100,
    y: Math.random() * 100
  }));
  return <div className="relative min-h-screen flex items-center justify-center overflow-hidden px-6 py-32">
      {/* Subtle animated background */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div animate={{
        scale: [1, 1.2, 1],
        opacity: [0.15, 0.25, 0.15]
      }} transition={{
        duration: 10,
        repeat: Infinity,
        ease: 'easeInOut'
      }} className="absolute top-1/4 left-1/4 w-[600px] h-[600px] bg-blue-500/20 rounded-full blur-3xl" />
        <motion.div animate={{
        scale: [1, 1.3, 1],
        opacity: [0.15, 0.25, 0.15]
      }} transition={{
        duration: 12,
        repeat: Infinity,
        ease: 'easeInOut',
        delay: 3
      }} className="absolute bottom-1/4 right-1/4 w-[600px] h-[600px] bg-violet-500/20 rounded-full blur-3xl" />
      </div>

      {/* Floating particles */}
      {particles.map(particle => <motion.div key={particle.id} initial={{
      opacity: 0,
      x: `${particle.x}vw`,
      y: `${particle.y}vh`
    }} animate={{
      opacity: [0, 0.6, 0.6, 0],
      y: [`${particle.y}vh`, `${particle.y - 30}vh`],
      x: [`${particle.x}vw`, `${particle.x + 10}vw`]
    }} transition={{
      duration: particle.duration,
      repeat: Infinity,
      delay: particle.delay,
      ease: 'easeInOut'
    }} className="absolute w-1 h-1 bg-blue-300/60 rounded-full" />)}

      {/* Geometric shapes */}
      <motion.div animate={{
      rotate: 360,
      scale: [1, 1.1, 1]
    }} transition={{
      duration: 25,
      repeat: Infinity,
      ease: 'linear'
    }} className="absolute top-20 right-20 w-40 h-40 border border-blue-400/20 rounded-lg" />
      <motion.div animate={{
      rotate: -360,
      scale: [1, 1.15, 1]
    }} transition={{
      duration: 20,
      repeat: Infinity,
      ease: 'linear'
    }} className="absolute bottom-32 left-20 w-32 h-32 border border-violet-400/20 rounded-full" />

      <div className="relative z-10 max-w-5xl mx-auto text-center">
        <motion.div initial={{
        opacity: 0,
        y: 30
      }} animate={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.8,
        delay: 0.2
      }} className="mb-12">
          <motion.span animate={{
          opacity: [0.4, 0.7, 0.4]
        }} transition={{
          duration: 3,
          repeat: Infinity
        }} className="text-blue-300 font-medium tracking-[0.2em] uppercase text-xs">
            Powered by Intelligence
          </motion.span>
        </motion.div>

        <motion.h1 initial={{
        opacity: 0,
        y: 30
      }} animate={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.8,
        delay: 0.4
      }} className="text-6xl md:text-7xl lg:text-8xl font-bold mb-16 leading-[1.1] tracking-tight">
          A marketplace for{' '}
          <motion.span animate={{
          backgroundPosition: ['0% 50%', '100% 50%', '0% 50%']
        }} transition={{
          duration: 6,
          repeat: Infinity,
          ease: 'linear'
        }} className="inline-block bg-gradient-to-r from-blue-300 via-violet-300 to-pink-300 bg-clip-text text-transparent" style={{
          backgroundSize: '200% 100%'
        }}>
            ideas
          </motion.span>
          .
        </motion.h1>

        <motion.p initial={{
        opacity: 0,
        y: 30
      }} animate={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.8,
        delay: 0.6
      }} className="text-lg md:text-xl text-gray-400 mb-20 max-w-2xl mx-auto leading-relaxed font-normal">
          postulate.ai connects idea creators with companies looking for
          innovation. Submit your breakthrough concepts, get reviewed by
          industry leaders, and turn ideas into reality.
        </motion.p>

        <motion.div initial={{
        opacity: 0,
        y: 30
      }} animate={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.8,
        delay: 0.8
      }} className="flex flex-col sm:flex-row items-center justify-center gap-6 mb-32">
          <motion.button whileHover={{
          scale: 1.02,
          boxShadow: '0 0 30px rgba(96, 165, 250, 0.4)'
        }} whileTap={{
          scale: 0.98
        }} className="group relative px-10 py-5 rounded-lg bg-gradient-to-r from-blue-500 via-violet-500 to-pink-500 text-white font-semibold text-base overflow-hidden">
            <motion.div className="absolute inset-0 bg-gradient-to-r from-blue-600 via-violet-600 to-pink-600" initial={{
            opacity: 0
          }} whileHover={{
            opacity: 1
          }} transition={{
            duration: 0.3
          }} />
            <span className="relative z-10 flex items-center gap-3">
              Join Creator Waitlist
              <motion.div animate={{
              x: [0, 4, 0]
            }} transition={{
              duration: 2,
              repeat: Infinity
            }}>
                <ArrowRight className="w-4 h-4" />
              </motion.div>
            </span>
          </motion.button>

          <motion.button whileHover={{
          scale: 1.02,
          borderColor: 'rgba(167, 139, 250, 0.6)'
        }} whileTap={{
          scale: 0.98
        }} className="px-10 py-5 rounded-lg border border-violet-400/30 bg-violet-500/5 text-white font-semibold text-base hover:bg-violet-500/10 transition-all duration-300">
            Join Company Waitlist
          </motion.button>
        </motion.div>

        <motion.div initial={{
        opacity: 0
      }} animate={{
        opacity: 1
      }} transition={{
        duration: 1,
        delay: 1.2
      }} className="flex flex-wrap items-center justify-center gap-16 text-sm">
          {[{
          label: 'Secure NDA Protection',
          color: 'bg-emerald-400'
        }, {
          label: 'AI-Powered Matching',
          color: 'bg-blue-400'
        }, {
          label: 'Fair Compensation',
          color: 'bg-violet-400'
        }].map((item, index) => <motion.div key={item.label} initial={{
          opacity: 0,
          y: 20
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          delay: 1.4 + index * 0.1
        }} className="flex items-center gap-3">
              <motion.div animate={{
            scale: [1, 1.2, 1],
            opacity: [0.4, 0.8, 0.4]
          }} transition={{
            duration: 2.5,
            repeat: Infinity,
            delay: index * 0.4
          }} className={`w-1.5 h-1.5 rounded-full ${item.color}`} />
              <span className="text-gray-500 font-light tracking-wide text-xs uppercase">
                {item.label}
              </span>
            </motion.div>)}
        </motion.div>
      </div>
    </div>;
}